<div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">

					<li><a class="has-arrow " href="userlist.php">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">User</span>
						</a>
					</li>

                    <li><a class="has-arrow " href="category.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Category</span>
						</a>
                        
                    </li> 
					<li><a class="has-arrow " href="specification.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Specification</span>
						</a>
                        
                    </li> 
					<li><a class="has-arrow " href="postlist.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">All Posts</span>
						</a>
                        
                    </li> 
					<li><a class="has-arrow " href="cityadd.php">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">City</span>
						</a>
					</li>

					

					<!-- <li><a class="has-arrow " href="requirementlist.php" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Requirements</span>
						</a>
					</li>

					<li><a class="has-arrow " href="Tasks.php" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Tasks</span>
						</a>
					</li> -->
                </ul>
				<!-- <div class="add-menu-sidebar">
					<img src="images/calendar.png" alt="" class="mr-3">
					<p class="	font-w500 mb-0">View your Calendar</p>
				</div> -->
				<div class="copyright">
					<!-- <p><strong>The Data Tech Lab Inc</strong> © 2022 All Rights Reserved</p>
					<p>Made with <span class="heart"></span> by TDTL</p> -->
				</div>
			</div>
        </div>