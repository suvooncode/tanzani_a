<?php
include("init.php");

session_destroy();
redirectfn("index.php");

?>